#  ID in context 83401512
class Stack:
    def __init__(self):
        self.items = []

    def isEmpty(self):
        return self.items == []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        return self.items.pop()

    def peek(self):
        return self.items[len(self.items) - 1]

    def size(self):
        return len(self.items)


def solution(numbers):
    st = Stack()
    operator = ['+', '-', '*', '/']
    for i in numbers:
        if i in operator:
            if i == '+':
                elem_1, elem_2 = st.pop(), st.pop()
                rez = elem_2 + elem_1
                st.push(rez)
            if i == '-':
                elem_1, elem_2 = st.pop(), st.pop()
                rez = elem_2 - elem_1
                st.push(rez)
            if i == '*':
                elem_1, elem_2 = st.pop(), st.pop()
                rez = elem_2 * elem_1
                st.push(rez)
            if i == '/':
                elem_1, elem_2 = st.pop(), st.pop()
                rez = elem_2 // elem_1
                st.push(rez)
        else:
            st.push(int(i))
    return int(st.peek())


if __name__ == '__main__':
    inp_string = input().split()
    print(solution(inp_string))
