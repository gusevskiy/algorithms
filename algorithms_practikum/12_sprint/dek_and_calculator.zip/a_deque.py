#  ID in context 83230735
class Deka:
    def __init__(self, max_n):
        self.element = [None] * max_n
        self.max_n = max_n
        self.head = 0
        self.tail = 0
        self.size = 0

    def isEmpty(self):
        return self.size == 0

    def push_back(self, item):
        if self.size != self.max_n:
            self.element[self.tail] = item
            self.tail = (self.tail + 1) % self.max_n
            self.size += 1
        else:
            raise OverflowError

    def push_front(self, item):
        if self.size != self.max_n:
            self.element[self.head - 1] = item
            self.head = (self.head - 1) % self.max_n
            self.size += 1
        else:
            raise OverflowError

    def pop_back(self):
        if self.isEmpty():
            raise IndexError
        item = self.element[self.tail - 1]
        self.element[self.tail - 1] = None
        self.tail = (self.tail - 1) % self.max_n
        self.size -= 1
        return item

    def pop_front(self):
        if self.isEmpty():
            raise IndexError
        item = self.element[self.head]
        self.element[self.head] = None
        self.head = (self.head + 1) % self.max_n
        self.size -= 1
        return item


def main():
    count_command = int(input())
    queue_size = int(input())

    queue = Deka(queue_size)
    commands = {
        'push_front': queue.push_front,
        'push_back': queue.push_back,
        'pop_front': queue.pop_front,
        'pop_back': queue.pop_back,
    }
    for i in range(count_command):
        command = input()
        operation, *value = command.split()
        if value:
            try:
                result = commands[operation](int(*value))
                if result is not None:
                    print(result)
            except OverflowError:
                print('error')
        else:
            try:
                result = commands[operation]()
                print(result)
            except IndexError:
                print('error')


if __name__ == '__main__':
    main()
